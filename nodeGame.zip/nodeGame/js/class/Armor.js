function Armor(armorId){
	switch (armorId){
		case 0:
			//Features
			this.armorName = "Weak";
			this.armor = 3;
			break;
		case 1:
			//Features
			this.armorName = "Medium";
			this.armor = 6;
			break;
		case 2:
			//Features
			this.armorName = "Heavy";
			this.armor = 10;
			break;
		}
}