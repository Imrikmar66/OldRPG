# Authors

This is the alphabetically sorted list of contributors to PathFinding.js:

Anders Riutta <https://github.com/ariutta><br>
Chris Khoo <https://github.com/chriskck><br>
Gerjo <https://github.com/Gerjo><br>
Juan Pablo Canepa <https://github.com/jpcanepa><br>
Mat Gadd <https://github.com/Drarok><br>
Murilo Pereira <https://github.com/mpereira><br>
Nathan Witmer <https://github.com/zerowidth><br>
rafaelcastrocouto <https://github.com/rafaelcastrocouto><br>
Raminder Singh <https://github.com/imor><br>
Ricardo Tomasi <https://github.com/ricardobeat><br>
Rodrigo Navarro <https://github.com/reu><br>
Rory O'Kane <https://github.com/roryokane><br>
Stuart Lee <https://github.com/beeglebug><br>
surrim <https://github.com/surrim><br>
Tapio Vierros <https://github.com/tapio><br>
Willem Mulder <https://github.com/willemmulder><br>
Xueqiao Xu <https://github.com/qiao>
