#Welcome to PathFinding.js documentation

Table of Contents

* User Guide
    * [Introduction](./user-guide/introduction.md)
    * [Installation](./user-guide/installation.md)
	* [Basic Usage](./user-guide/basic-usage.md)
	* [Advanced Usage](./user-guide/advanced-usage.md)
	* [FAQ](./user-guide/faq.md)
* Contributor Guide
    * [Contributing](./contributor-guide/contributing.md)
	* [Developing](./contributor-guide/developing.md)
	* [Authors](./contributor-guide/authors.md)